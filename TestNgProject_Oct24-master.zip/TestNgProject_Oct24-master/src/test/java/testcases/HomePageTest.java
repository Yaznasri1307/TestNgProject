package testcases;

import org.testng.annotations.Test;

public class HomePageTest extends BaseClass{
	
	@Test
	public void TC03_SomeName() {
	
		System.out.println("Inside TC_03");
	}

}
